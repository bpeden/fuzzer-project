/* version.h - version defines for thttpd and libhttpd */

#ifndef _VERSION_H_
#define _VERSION_H_

#define SERVER_SOFTWARE "thttpd/2.19 23jun00"
#define SERVER_ADDRESS "http://www.acme.com/software/thttpd/"

#endif /* _VERSION_H_ */
